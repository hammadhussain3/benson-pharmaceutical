<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class LoanRequest extends FormRequest
{
    public function authorize()
    {
        return true; // Adjust according to your authorization logic
    }

    public function rules()
    {
        $currentYear = date('Y');
        $currentMonth = date('n');
        
        return [
            'employee' => 'required|exists:employees,id',
            'amount' => 'required|numeric|min:0',
            'payback_months' => 'required|integer|min:1',
            'remaining' => 'required|numeric|min:0',
            'company' => 'required|exists:companies,id',
            'month' => [
                'required',
                'integer',
                'min:1',
                'max:12',
                function ($attribute, $value, $fail) use ($currentYear, $currentMonth) {
                    if (request()->year == $currentYear && $value > $currentMonth) {
                        $fail('The selected month cannot be in the future.');
                    }
                },
            ],

            'year' => [
                'required',
                'integer',
                'min:' . ($currentYear - 9),
                'max:' . $currentYear,
            ],
        ];
    }
}